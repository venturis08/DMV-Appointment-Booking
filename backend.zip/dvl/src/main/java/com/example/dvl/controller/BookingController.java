package com.example.dvl.controller;

import com.example.dvl.dto.CheckSlotsDto;
import com.example.dvl.modal.Booking;
import com.example.dvl.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin("http://localhost:3000")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping("/book/checkSlots")
    public ResponseEntity booking(@RequestBody CheckSlotsDto checkSlotsDto){
        System.out.println(checkSlotsDto.getAppointmentDate());
        List<String> slotsAvailable = bookingService.getAllAvailableSlots(checkSlotsDto);
        if(slotsAvailable.size() == 0){
            HashMap<Object, Object> map = new HashMap<>();
            map.put("message","Slots Not Available");
            return new ResponseEntity(map, HttpStatus.OK);
        }
        return new ResponseEntity(slotsAvailable, HttpStatus.OK);
    }

    @PostMapping("/book")
    public ResponseEntity bookSlot(@RequestBody Booking booking){
        booking.setStatus("BOOKED");
        Booking booking1 = bookingService.bookService(booking);
        return new ResponseEntity(booking1, HttpStatus.OK);
    }

    @PostMapping("/booking/update")
    public ResponseEntity updateBooking(@RequestBody Booking booking){
        Booking booking1 = bookingService.bookService(booking);
        return new ResponseEntity(booking1, HttpStatus.OK);
    }

    @GetMapping("/user/bookings/{userId}")
    public ResponseEntity getAllBookingsOfUser(@PathVariable("userId") Integer userId){
        System.out.println("userId "+userId);
        List<Booking> bookings = bookingService.getAllUserBookings(userId);
        System.out.println("Bookings size : "+bookings.size());
        bookings = bookings.stream().filter(booking -> booking.getStatus().equals("BOOKED")).collect(Collectors.toList());
        System.out.println("Bookings size After: "+bookings.size());
        return new ResponseEntity(bookings, HttpStatus.OK);
    }

    @GetMapping("/bookings/{bookingId}")
    public ResponseEntity getBooking(@PathVariable("bookingId") Integer bookingId){
        Booking booking = bookingService.getBookingById(bookingId);
        return new ResponseEntity(booking, HttpStatus.OK);
    }

    @GetMapping("/user/booking/cancel/{bookingId}")
    public ResponseEntity cancelBooking(@PathVariable("bookingId") Integer bookingId){
        Booking booking = bookingService.getBookingById(bookingId);
        bookingService.cancelService(booking);
        return new ResponseEntity(booking, HttpStatus.OK);
    }


}
