package com.example.dvl.modal;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class DVLHolidayList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(columnDefinition = "DATE")
    private LocalDate holidayDate;

    private String reason;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getHolidayDate() {
        return holidayDate;
    }

    public void setHolidayDate(LocalDate holidayDate) {
        this.holidayDate = holidayDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public DVLHolidayList(int id, LocalDate holidayDate, String reason) {
        this.id = id;
        this.holidayDate = holidayDate;
        this.reason = reason;
    }

    public DVLHolidayList() {
    }
}
