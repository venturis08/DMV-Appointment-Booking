package com.example.dvl.repo;

import com.example.dvl.modal.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepo extends JpaRepository<Booking, Integer> {

    List<Booking> findByUserId(Integer userId);

    Optional<Booking> findById(int bookingId);

    Booking getBookingById(int id);

    List<Booking> findAllByLocationAndAndAppointmentTypeAndAppointmentDateAndSlot(String location, String appointmentType, LocalDate localDate, String slot);
}
