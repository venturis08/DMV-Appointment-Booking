package com.example.dvl.service;

import com.example.dvl.modal.Booking;
import com.example.dvl.modal.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class UserNotification {
    @Autowired
    private JavaMailSender mailSender;

    @Value("{mail.user}")
    private String fromMail;
    @Autowired
    private UserService userService;


    public void sendBookingNotification(Booking booking){
        User user = userService.getUserById(booking.getUserId());
        String toMail = user.getEmail();
        String subject = "AppointConfirmation for "+booking.getAppointmentType()+" location "+booking.getLocation();

        String body =  "Hi "+user.getFullName()+" \n \n"
                +"Appointment Booked Successfully \n" +
                      " Appointment Type : "+booking.getAppointmentType()+" \n " +
                      " Appointment Date : "+booking.getAppointmentDate()+"\n "+
                        "Location : "+booking.getLocation()+" \n"+
                        "Slot : "+booking.getSlot()
                        +"\n \n"+
                        "Regards \n"+
                    "Department Of Vehicles and Licence"

                ;


        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromMail);
        message.setTo(toMail);
        message.setText(body);
        message.setSubject(subject);
        mailSender.send(message);
        System.out.println("Booking mail Sent");
    }

    public void sendCancelNotification(Booking booking){
        User user = userService.getUserById(booking.getUserId());
        String toMail = user.getEmail();
        String subject = "Appointment Cancellation for "+booking.getAppointmentType()+" location "+booking.getLocation();
        String body = "Hi "+user.getFullName()+" \n \n"+
                "Appointment Cancelled Successfully \n" +
                " Appointment Type : "+booking.getAppointmentType()+" \n " +
                " Appointment Date : "+booking.getAppointmentDate()+"\n "+
                "Location : "+booking.getLocation()+" \n"+
                "Slot : "+booking.getSlot()
                + "Regards \n"+
                "Department Of Vehicles and Licence";

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromMail);
        message.setTo(toMail);
        message.setText(body);
        message.setSubject(subject);
        mailSender.send(message);
        System.out.println("Booking mail Sent");
    }

}
