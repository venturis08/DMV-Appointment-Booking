package com.example.dvl.repo;

import com.example.dvl.modal.DVLHolidayList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DVlRepo extends JpaRepository<DVLHolidayList, Integer> {
}
