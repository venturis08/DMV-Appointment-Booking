package com.example.dvl.controller;

import com.example.dvl.dto.LoginDto;
import com.example.dvl.modal.User;
import com.example.dvl.service.UserNotification;
import com.example.dvl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
@CrossOrigin("http://localhost:3000")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserNotification userNotification;

    @PostMapping("/user/login")
    public ResponseEntity login(@RequestBody LoginDto loginDto){
        HashMap<Object, Object> map = new HashMap<>();
        User user = userService.checkLogin(loginDto);
        if(user == null){
            map.put("status", "Failure");
            map.put("message","Wrong Username or Password");
        } else {
            return new ResponseEntity(user, HttpStatus.OK);
        }
        return new ResponseEntity(map, HttpStatus.OK);
    }


    @PostMapping("/user/register")
    public ResponseEntity register(@RequestBody User user){
        System.out.println(user.toString());
        User user1 = userService.save(user);

        if(user1 == null){
            HashMap<Object, Object> map = new HashMap<>();
            map.put("Status", "Failure");
            map.put("Error", "UserName already exists choose another");
            return new ResponseEntity(map, HttpStatus.OK);
        }
        return new ResponseEntity(user1, HttpStatus.OK);
    }
}
