package com.example.dvl.repo;

import com.example.dvl.modal.DVLWorkingTiming;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DVLWorkingTimingRepo extends JpaRepository<DVLWorkingTiming, Integer> {
    Optional<DVLWorkingTiming> findByDay(String day);
}
