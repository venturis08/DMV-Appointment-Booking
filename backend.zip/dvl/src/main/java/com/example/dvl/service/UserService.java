package com.example.dvl.service;

import com.example.dvl.dto.LoginDto;
import com.example.dvl.modal.User;
import com.example.dvl.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;


    public User checkLogin(LoginDto loginDto) {
            User user = userRepo.getByUserName(loginDto.getUserName());
            if(user != null && user.getPassword().equals(loginDto.getPassword())){
                return user;
            }
            return null;
    }

    public User save(User user) {
        User user1 = userRepo.getUserByUserName(user.getUserName());
            if (user1 == null) {
                return userRepo.save(user);
        }
        return null;
    }

    public User getUserById(int userId){
        User user = userRepo.getById(userId);
        return user;
    }
}
