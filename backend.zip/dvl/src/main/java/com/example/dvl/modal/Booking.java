package com.example.dvl.modal;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int userId;

    private String applicationNumber;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate appointmentDate;

    private String vehicleNumber;

    private String appointmentType;

    private String location;

    private String slot;

    @Column(columnDefinition = "varchar(50) default 'BOOKED'")
    private String status;

    @Temporal(TemporalType.DATE)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date bookedOn;


    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date bookingUpdatedOn;

    @PrePersist
    public void prePersist(){
        this.bookedOn = new Date();
        this.bookingUpdatedOn = new Date();
    }

    @PreUpdate
    public void preUpdate(){
        this.bookingUpdatedOn = new Date();
    }

    public Booking(int id, int userId, String applicationNumber, LocalDate appointmentDate, String vehicleNumber, String slot, String status, Date bookedOn, Date bookingUpdatedOn) {
        this.id = id;
        this.userId = userId;
        this.applicationNumber = applicationNumber;
        this.appointmentDate = appointmentDate;
        this.vehicleNumber = vehicleNumber;
        this.slot = slot;
        this.status = status;
        this.bookedOn = bookedOn;
        this.bookingUpdatedOn = bookingUpdatedOn;
    }

   }
