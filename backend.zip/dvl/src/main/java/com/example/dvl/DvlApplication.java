package com.example.dvl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DvlApplication {

    public static void main(String[] args) {
        SpringApplication.run(DvlApplication.class, args);
    }

}
