package com.example.dvl.service;

import com.example.dvl.dto.CheckSlotsDto;
import com.example.dvl.modal.Booking;
import com.example.dvl.modal.DVLHolidayList;
import com.example.dvl.modal.DVLWorkingTiming;
import com.example.dvl.repo.BookingRepo;
import com.example.dvl.repo.DVlRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private DVlRepo dVlRepo;

    @Autowired
    private BookingRepo bookingRepo;

    @Autowired
    private DVLWorkingTimingService dvlWorkingTimingService;

    @Autowired
    private UserNotification userNotification;

    public boolean checkIfDepartmentIsHoliday(LocalDate localDate){
        List<DVLHolidayList> dvlHolidayLists = dVlRepo.findAll();
        LocalDate today = LocalDate.now();
        /**
         * Checking if the selected date is before current date.
         */
        if(localDate.isBefore(today)){
            return true;
        }
        for(DVLHolidayList dvlHolidayList : dvlHolidayLists){
            if(dvlHolidayList.getHolidayDate().equals(localDate)){
                return true;
            }
        }
        System.out.println(localDate);
        return false;
    }

    public List<String> getAllAvailableSlots(CheckSlotsDto checkSlotsDto) {
        List<String> slots = new ArrayList<>();
        if(checkIfDepartmentIsHoliday(checkSlotsDto.getAppointmentDate())){
            return slots;
        } else {
            String day = checkSlotsDto.getAppointmentDate().getDayOfWeek().toString();
            DVLWorkingTiming dvlWorkingTiming = dvlWorkingTimingService.getDVLWorkingTimingByDay(day);
            if(dvlWorkingTiming == null){
                return slots;
            } else {
                String workTimings = dvlWorkingTiming.getWorkTimings();
                String arr[] = workTimings.split("-");
                int slotStart = Integer.parseInt(arr[0]), slotEnd = Integer.parseInt(arr[1]);
                while(slotStart < slotEnd){
                    String slot = slotStart+"-"+(slotStart + 1);
                    slotStart++;
                    if(checkSlotAvailablity(slot, checkSlotsDto)){
                        slots.add(slot);
                    }

                }
            }
        }
        return slots;
    }

    private boolean checkSlotAvailablity(String slot, CheckSlotsDto checkSlotsDto) {
        List<Booking> bookings = bookingRepo.findAllByLocationAndAndAppointmentTypeAndAppointmentDateAndSlot(checkSlotsDto.getLocation(), checkSlotsDto.getApplicationType(), checkSlotsDto.getAppointmentDate(), slot);
        if(bookings.size() == 3){
            return false;
        }
        return true;
    }

    public Booking bookService(Booking booking){
        booking.setStatus("BOOKED");
        Booking booking1 = bookingRepo.save(booking);
        userNotification.sendBookingNotification(booking);
        return booking1;
    }

    public Booking cancelService(Booking booking){
        booking.setStatus("CANCELLED");
        Booking booking1 = bookingRepo.save(booking);
        userNotification.sendCancelNotification(booking);
        return booking1;
    }

    public List<Booking> getAllUserBookings(int userId){
        List<Booking> bookings = bookingRepo.findByUserId(userId);
        System.out.println(bookings.size());
        return bookings;
    }

    public Booking getBookingById(int bookingId) {
        Booking booking = bookingRepo.getBookingById(bookingId);
        return booking;
    }
}
