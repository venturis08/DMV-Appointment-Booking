package com.example.dvl.service;

import com.example.dvl.modal.DVLWorkingTiming;
import com.example.dvl.repo.DVLWorkingTimingRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DVLWorkingTimingService {

    @Autowired
    private DVLWorkingTimingRepo dvlWorkingTimingRepo;

    public DVLWorkingTiming getDVLWorkingTimingByDay(String day){
        Optional<DVLWorkingTiming> dvlWorkingTiming = dvlWorkingTimingRepo.findByDay(day);
        if(dvlWorkingTiming.isPresent()){
            return dvlWorkingTiming.get();
        }
        return null;
    }

}
