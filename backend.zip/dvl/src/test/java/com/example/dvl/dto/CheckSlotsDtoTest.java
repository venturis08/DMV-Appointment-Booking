package com.example.dvl.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class CheckSlotsDtoTest {

    CheckSlotsDto checkSlotsDto;

    @BeforeEach
    public void setUp() throws ParseException {
        LocalDate localDate = LocalDate.now();
        checkSlotsDto = new CheckSlotsDto("1234",localDate,"123");
    }

    @Test
    void getApplicationNumber() {
        assertEquals("1234", checkSlotsDto.getApplicationNumber());
    }

    @Test
    void setApplicationNumber() {
        checkSlotsDto.setApplicationNumber("12345");
        assertEquals("12345", checkSlotsDto.getApplicationNumber());
    }

    @Test
    void getAppointmentDate() {
        LocalDate now = LocalDate.now();
        assertEquals(now, checkSlotsDto.getAppointmentDate());
    }


    @Test
    void getVehicleNumber() {
        assertEquals("123", checkSlotsDto.getVehicleNumber());
    }

    @Test
    void setVehicleNumber() {
        checkSlotsDto.setVehicleNumber("12345");
        assertEquals("12345", checkSlotsDto.getVehicleNumber());
    }
}