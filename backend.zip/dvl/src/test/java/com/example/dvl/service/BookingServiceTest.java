package com.example.dvl.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class BookingServiceTest {


    @Autowired
    private BookingService bookingService;

    @Test
    void checkIfBankIsHoliday() {
        boolean isHoliday = bookingService.checkIfDepartmentIsHoliday(LocalDate.now());
        assertFalse(isHoliday);
    }

    @Test
    void getAllAvailableSlots() {
    }

    @Test
    void bookService() {
    }

    @Test
    void getAllUserBookings() {
    }

    @Test
    void getBookingById() {
    }
}