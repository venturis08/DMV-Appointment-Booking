package com.example.dvl.modal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    User user;

    @BeforeEach
    public void setUp() throws ParseException {
        LocalDate now = LocalDate.now();
        user = new User(1, "Test User", "Test@gmail.com","Test@123","test@009",now);
    }

    @Test
    void getId() {
        assertEquals(1, user.getId());
    }

    @Test
    void setId() {
        user.setId(2);
        assertEquals(2, user.getId());
    }

    @Test
    void getFullName() {
        assertEquals("Test User", user.getFullName());
    }

    @Test
    void setFullName() {
        user.setFullName("Test User 1");
        assertEquals("Test User 1", user.getFullName());
    }

    @Test
    void getEmail() {
        assertEquals("Test@gmail.com", user.getEmail());
    }

    @Test
    void setEmail() {
        user.setEmail("Test1@gmail.com");
        assertEquals("Test1@gmail.com", user.getEmail());
    }

    @Test
    void getUserName() {
        assertEquals("Test@123", user.getUserName());
    }

    @Test
    void setUserName() {
        user.setUserName("Test@1231");
        assertEquals("Test@1231", user.getUserName());
    }

    @Test
    void getPassword() {
        assertEquals("test@009", user.getPassword());
    }

    @Test
    void setPassword() {
        user.setPassword("test@008");
        assertEquals("test@008", user.getPassword());
    }

}