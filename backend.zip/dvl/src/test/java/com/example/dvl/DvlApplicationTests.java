package com.example.dvl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DvlApplicationTests {

    @Test
    void contextLoads() {
    }

}
