package com.example.dvl.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoginDtoTest {

    LoginDto loginDto;

    @BeforeEach
    public void setUp(){
        loginDto = new LoginDto("userName", "password");

    }

    @Test
    void getUserName() {
        assertEquals("userName", loginDto.getUserName());
    }

    @Test
    void setUserName() {
        loginDto.setUserName("userName1");
        assertEquals("userName1", loginDto.getUserName());
    }

    @Test
    void getPassword() {
        assertEquals("password", loginDto.getPassword());
    }

    @Test
    void setPassword() {
        loginDto.setPassword("password1");
        assertEquals("password1", loginDto.getPassword());
    }
}