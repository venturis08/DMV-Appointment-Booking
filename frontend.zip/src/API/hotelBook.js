import makePostAPICall from "./index";

const module = `book`;
const BookService = (data, date) => {
  const payload = {
    userId: localStorage.getItem("id"),
    applicationNumber: data.applicationNumber,
    vehicleNumber: data.vehicleNumber,
    appointmentDate: date,
    slot: data.service,
    appointmentType:data.appointmentType,
    location:data.location
  };
  let res = makePostAPICall(module, payload);
  if (res) {
    alert("Booking success")
    window.location.href = "/bookings";
  }
};

const getSlots = async (data) => {
  let resp = await makePostAPICall("book/checkSlots", data);
  return resp?.data;
};
export { BookService, getSlots };
