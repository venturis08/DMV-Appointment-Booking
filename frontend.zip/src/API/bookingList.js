import getCall from "./Get";
import makePostAPICall from "./index";
let id = localStorage.getItem("userId");
const EditBookService = (data, id, date) => {
  const payload = {
    userId: localStorage.getItem("id"),
    applicationNumber: data.applicationNumber,
    vehicleNumber: data.vehicleNumber,
    appointmentType:data.appointmentType,
    location:data.location,
    appointmentDate: date,
    slot: data.service,

    id: id,
  };
  let resp = makePostAPICall(`booking/update`, payload);
  if (resp) {
    window.location.href = "/bookings";
  }
};

const BookingHistory = async () => {
  let id = localStorage.getItem("id");
  let resp = await getCall(`/user/bookings/${id}`);
  return resp?.data;
};
const BookingHistoryOld = async () => {
  let resp = await getCall(`/user/bookings/${id}`);
  return resp?.data;
};
const deleteBooking = async (item) => {
  let resp = await getCall(`/user/booking/cancel/${item.id}`);
  return resp?.data;
};
export { EditBookService, BookingHistory, BookingHistoryOld, deleteBooking };
