import makePostAPICall from "./index";
const module = "user/login";
const LoginSubmit = async (data) => {
  const payload = {
    userName: data.userName,
    password: data.password,
    captch: data.captcha,
  };
  let resp = await makePostAPICall(module, payload);
  console.log(resp);
  if (resp.status === "Failure") {
    alert("Invalid email or Password");
  } else if (resp.status === 200) {
    localStorage.setItem("id", resp.data.id);
    window.location.href = "/bookservice";
  }
};
export default LoginSubmit;
