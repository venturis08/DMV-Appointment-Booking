import makePostAPICall from "./index";
const module = "user/register";
const SignupSubmit = async (data) => {
  const payload = {
    fullName: data.fullName,
    email: data.email,
    userName: data.userName,
    password: data.password,
    dateOfBirth: data.dob,
  };
  let resp = await makePostAPICall(module, payload);

  if (resp?.data?.status === "Failure") {
    alert("UserName already registered, choose another");
  } else {
    window.location.href = "/login";
  }
};
export default SignupSubmit;
