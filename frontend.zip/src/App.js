import logo from "./logo.svg";
import "./App.css";
import Login from "../src/pages/Login";

function App() {
  return (
    <div className="App">
      <Login />
    </div>
  );
}

export default App;

