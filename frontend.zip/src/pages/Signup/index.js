import { NavLink } from "react-router-dom";
import React from "react";
import { Grid, TextField, Button, Box } from "@mui/material";
import SignupSubmit from "../../API/signup";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "./signup.css";
import Header from "../../components/header";
import Footer from "../../components/footer";
const Signup = () => {
  return (
    <>
      <Header />
      <div className="mainDiv">
        <Box
          display="flex"
          flexDirection={"column"}
          maxWidth={400}
          alignItems="center"
          marginLeft={"65%"}
          padding={2}
          backgroundColor="white"
        >
          <Formik
            initialValues={{
              fullName: "",
              email: "",
              password: "",
              userName: "",
              captcha: "",
              dob: "",
            }}
            onSubmit={async (values) => {
              if (values.captcha !== "qGphJD") {
                alert("Captch is wrong");
              } else {
                SignupSubmit(values);
              }
            }}
            validateOnChange={false}
            validateOnBlur={false}
            validationSchema={Yup.object().shape({
              email: Yup.string()
                .email("please enter valid email")
                .required("Required"),
              password: Yup.string()
                .required("Required")
                .min(8, "Must be 8 characters or more")
                .matches(/[a-z]+/, "One lowercase character")
                .matches(/[A-Z]+/, "One uppercase character")
                .matches(/[@$!%*#?&]+/, "One special character")
                .matches(/\d+/, "One number"),
            })}
          >
            {(props) => {
              props.submitCount > 0 && (props.validateOnChange = true);
              const {
                values,
                touched,
                errors,
                isSubmitting,
                handleChange,

                handleBlur,
              } = props;
              return (
                <Form>
                  <Field
                    as={TextField}
                    label="FullName"
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    type="text"
                    name="fullName"
                    placeholder="Enter Full Name"
                    id="outlined-basic"
                    helperText={<ErrorMessage name="fullName" />}
                    variant="outlined"
                    value={values.fullName}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    margin="normal"
                    fullWidth
                  />

                  <Field
                    as={TextField}
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    label="Password"
                    placeholder="Enter password"
                    name="password"
                    helperText={<ErrorMessage name="password" />}
                    type="password"
                    id="outlined-basic"
                    variant="outlined"
                    value={values.password}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={
                      errors.password && touched.password
                        ? "text-input error"
                        : "text-input"
                    }
                    fullWidth
                  />
                  <Field
                    as={TextField}
                    label="Email"
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    type="text"
                    name="email"
                    placeholder="Enter email"
                    id="outlined-basic"
                    helperText={<ErrorMessage name="email" />}
                    variant="outlined"
                    value={values.email}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    margin="normal"
                    className={
                      errors.email && touched.email
                        ? "text-input error"
                        : "text-input"
                    }
                    fullWidth
                  />

                  <Field
                    as={TextField}
                    label="Username"
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    type="text"
                    name="userName"
                    placeholder="Enter Your Username"
                    id="outlined-basic"
                    helperText={<ErrorMessage name="userName" />}
                    variant="outlined"
                    value={values.userName}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    margin="normal"
                    fullWidth
                  />
                  <Field
                    as={TextField}
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    type="date"
                    name="dob"
                    label="Date of Birth"
                    placeholder="Date of Birth"
                    id="outlined-basic"
                    helperText={<ErrorMessage name="dob" />}
                    variant="outlined"
                    value={values.dob}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    margin="normal"
                    fullWidth
                  />

                  <img
                    height="10%"
                    width="20%"
                    src={
                      "https://www.pandasecurity.com/en/mediacenter/src/uploads/2014/09/avoid-captcha.jpg"
                    }
                    alt="Captcha"
                  ></img>
                  <Field
                    as={TextField}
                    label="Captcha"
                    sx={{
                      // width: { sm: 200, md: 300 },
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    type="text"
                    name="captcha"
                    placeholder="Enter captcha"
                    id="outlined-basic"
                    helperText={<ErrorMessage name="captcha" />}
                    variant="outlined"
                    value={values.captcha}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    margin="normal"
                    className={
                      errors.captcha && touched.captcha
                        ? "text-input error"
                        : "text-input"
                    }
                    fullWidth
                  />
                  <Grid container spacing={2}>
                    <Grid item>
                      {" "}
                      <Button
                        type="submit"
                        color="primary"
                        variant="contained"
                        // fullWidth
                        required
                        disabled={isSubmitting}
                      >
                        Register
                      </Button>
                    </Grid>
                    <Grid item>
                      {" "}
                      <NavLink to="/login" exact>
                        Login
                      </NavLink>
                    </Grid>
                  </Grid>
                </Form>
              );
            }}
          </Formik>
        </Box>
      </div>
      <Footer />
    </>
  );
};
export default Signup;
