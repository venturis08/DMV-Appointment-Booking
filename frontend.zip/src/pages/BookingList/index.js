import React, { useState, useEffect } from "react";
import { Grid, TextField, Button, Box, MenuItem, Select } from "@mui/material";
import {
  BookingHistory,
  BookingHistoryOld,
  deleteBooking,
  EditBookService,
} from "../../API/bookingList";
import { Formik, Form } from "formik";

import "./bookingList.css";
import Header from "../../components/header";
import { getSlots } from "../../API/hotelBook";
const BookingList = () => {
  const [services, setServices] = useState([]);
  const [editFlag, setEditFlag] = useState(false);

  const [editData, setEditData] = useState(null);

  const handleEdit = (item) => {
    console.log("Item is ", item)
    setDate(item.appointmentDate)
    console.log(item);
    setEditData(item);
    setEditFlag(true);
  };

  const getData = async () => {
    let data = await BookingHistory();

    setServices(data ? data : []);
  };
  const getHistory = async () => {
    let data = await BookingHistoryOld();
    setServices(data);
  };
  const handleDelete = (item) => {
    deleteBooking(item);
    window.location.reload();

  };

  const [date, setDate] = useState("");

  const [slotsOptions, setSlotOptions] = useState([]);

  const handlegetSlots = async (e, appNo, vehno) => {
    setDate(e.target.value);
    let payload = {
      applicationNumber: editData.applicationNumber,
      appointmentDate: e.target.value,
      vehicleNumber: editData.appointmentDate,

    };
    if (appNo && vehno && e.target.value) {
      let res_slots = await getSlots(payload);
      console.log(res_slots);
      setSlotOptions(res_slots);
    }
  };
  const handleCance =()=>{
    //
    window.location.href = "/bookings";
  }
  useEffect(() => {
    getData();
  }, []);

  return (
    <div className="main">
      <Header />

      {editFlag ? (
        <div>
          <Box
            display="flex"
            flexDirection={"column"}
            maxWidth={400}
            alignItems="center"
            justifyContent={"center"}
            margin="auto"
            marginTop={5}
            padding={2}
            marginBottom={10}
            boxShadow={"0px 5px 10px 0px "}
            backgroundColor="white"
          >
            <Grid align="center">
              <h2>Update Service</h2>
            </Grid>
            <Formik
              initialValues={{
                applicationNumber: editData.applicationNumber || "",
                city: editData.city || "",
                service: editData.slot || "",
                vehicleNumber: editData.vehicleNumber || "",
                appointmentType: editData.appointmentType || "",
                location:editData.location || ""
               
              }}
              onSubmit={async (values) => {
                EditBookService(values, editData.id, date);
              }}
              validateOnChange={false}
              validateOnBlur={false}
            >
              {(props) => {
                props.submitCount > 0 && (props.validateOnChange = true);
                const {
                  values,

                  isSubmitting,
                  handleChange,
                } = props;
                return (
                  <Form>

                  <p>Select Location</p>
               
                  <Select
                  value={values.location}
                  onChange={handleChange}
                  name="location"
                  label="location"
                  size="small"
                  fullWidth
                >
                    <MenuItem value="NewYork">New York</MenuItem>;
                    <MenuItem value="Dallas">Dallas</MenuItem>;
                    <MenuItem value="Kansas">Kansas</MenuItem>;
                    <MenuItem value="Chicago">Chicago</MenuItem>;
                
                </Select>
                <br></br>
               
  
                <p>Select Appointment Type</p>
                 
                <Select
                value={values.appointmentType}
                onChange={handleChange}
                name="appointmentType"
                label="appointmentType"
                size="small"
                fullWidth
              >
                  <MenuItem value="LLR">LLR</MenuItem>;
                  <MenuItem value="VehicleRegistration">Vehicle Registration</MenuItem>;
              
              </Select>
              <br></br>
              <br></br>

                    <TextField
                      id="applicationNumber"
                      label="Application Number"
                      size="small"
                      fullWidth
                      type="text"
                      value={values.applicationNumber}
                      onChange={handleChange}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                    <TextField
                      fullWidth
                      size="small"
                      id="vehicleNumber"
                      label="Vehicle Number"
                      type="text"
                      style={{ marginTop: "5%" }}
                      value={values.vehicleNumber}
                      onChange={handleChange}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                    <TextField
                      fullWidth
                      id="date"
                      label="Select Date"
                      type="date"
                      size="small"
                      style={{ marginTop: "5%" }}
                      value={values.date || date}
                      onChange={(e) => {
                        handlegetSlots(
                          e,
                          values.applicationNumber,
                          values.vehicleNumber,
                          values.appointmentType,
                          values.location
                        );
                        handleChange();
                      }}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                    <p>Availabel Slots</p>
                    <Select
                      value={values.service||values.slot}
                      onChange={handleChange}
                      name="service"
                      label="service"
                      size="small"
                      fullWidth
                    >
                      {slotsOptions.map((item) => {
                        return <MenuItem value={item}>{item}</MenuItem>;
                      })}
                    </Select>

                    <br></br>

                    <br></br>

                    <Button
                      type="submit"
                      sx={{
                        // width: { sm: 200, md: 300 },
                        "& .MuiInputBase-root": {
                          height: 40,
                        },
                      }}
                      color="primary"
                      variant="contained"
                      size="small"
                      fullWidth
                      required
                      disabled={isSubmitting}
                    >
                      Update Service
                    </Button>
                    <br/>
                    <br/>
                    <Button
                    onClick ={()=>{handleCance()}}
                      sx={{
                        // width: { sm: 200, md: 300 },
                        "& .MuiInputBase-root": {
                          height: 40,
                        },
                      }}
                      color="primary"
                      variant="contained"
                      size="small"
                      fullWidth
                      required
                      disabled={isSubmitting}
                    >
                      Cancel
                    </Button>
                  </Form>
                );
              }}
            </Formik>
            <br></br>
          </Box>
        </div>
      ) : (
        <div>
          <Grid>
            

            <Grid className="data">
              <Grid className="tableHeader" container xs={12}>
              <Grid className="header-item-row" xs={1} item>
              {"Appointment Type"}
            </Grid>
            <Grid className="header-item-row" xs={1} item>
              {"Location"}
            </Grid>
                <Grid className="header-item-row" xs={2} item>
                  {"Application Number"}
                </Grid>
                <Grid className="header-item-row" xs={2} item>
                  {"Appointment Date"}
                </Grid>
                <Grid className="header-item-row" xs={2} item>
                  {"Vechiel Number"}
                </Grid>
                <Grid className="header-item-row" xs={1} item>
                  {"Status"}
                </Grid>
                <Grid className="header-item-row" xs={1} item>
                  {"Slot"}
                </Grid>
                <Grid className="header-item-row" xs={1} item>
                  {"Edit"}
                </Grid>
                <Grid className="header-item-row" xs={1} item>
                  {"Delete"}
                </Grid>
              </Grid>
              {services.map((item) => {
                return (
                  <Grid container xs={12}>
                  <Grid className="header-item-row" xs={1} item>
                      {item.appointmentType}
                    </Grid>
                    <Grid className="header-item-row" xs={1} item>
                      {item.location}
                    </Grid>
                    <Grid className="header-item-row" xs={2} item>
                      {item.applicationNumber}
                    </Grid>
                    <Grid className="header-item-row" xs={2} item>
                      {item.appointmentDate}
                    </Grid>
                    <Grid className="header-item-row" xs={2} item>
                      {item.vehicleNumber}
                    </Grid>
                    <Grid className="header-item-row" xs={1} item>
                      {item.status}
                    </Grid>
                    <Grid className="header-item-row" xs={1} item>
                      {item.slot}
                    </Grid>
                    <Grid
                      onClick={() => {
                        handleEdit(item);
                      }}
                      className="header-item-row"
                      xs={1}
                      item
                    >
                      {"Edit"}
                    </Grid>
                    <Grid
                      onClick={() => {
                        handleDelete(item);
                      }}
                      className="header-item-row"
                      xs={1}
                      item
                    >
                      {"Delete"}
                    </Grid>
                  </Grid>
                );
              })}
            </Grid>
          </Grid>
        </div>
      )}
    </div>
  );
};

export default BookingList;
