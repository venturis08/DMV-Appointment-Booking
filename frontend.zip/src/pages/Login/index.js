import { NavLink } from "react-router-dom";
import React from "react";
import { Grid, TextField, Button, Box } from "@mui/material";
import LoginSubmit from "../../API/login";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import Header from "../../components/header";
import "./login.css";
import Footer from "../../components/footer";
const Login = () => {
  return (
    <>
      <Header />
      <Grid container>
        <Grid sx={{ marginLeft: "75%", padding: "1%" }} item xs={12}>
          New User?
          <span style={{ color: "#4ee44e" }}>
            <NavLink to="/signup" exact>
              Register
            </NavLink>
          </span>
        </Grid>
      </Grid>
      <div className="mainDivlogin">
        <Box
          display="flex"
          lineHeight={4}
          flexDirection={"column"}
          maxWidth={400}
          alignItems="center"
          marginLeft={"65%"}
          padding={2}
          backgroundColor="white"
        >
          <Formik
            initialValues={{ userName: "", password: "", captcha: "" }}
            onSubmit={async (values) => {
              if (values.captcha !== "qGphJD") {
                alert("Captch is wrong");
              } else {
                LoginSubmit(values);
              }
            }}
            validateOnChange={false}
            validateOnBlur={false}
            validationSchema={Yup.object().shape({
              password: Yup.string()
                .required("Required")
                .min(8, "Must be 8 characters or more")
                .matches(/[a-z]+/, "One lowercase character")
                .matches(/[A-Z]+/, "One uppercase character")
                .matches(/[@$!%*#?&]+/, "One special character")
                .matches(/\d+/, "One number"),
            })}
          >
            {(props) => {
              props.submitCount > 0 && (props.validateOnChange = true);
              const {
                values,
                touched,
                errors,
                isSubmitting,
                handleChange,

                handleBlur,
              } = props;
              return (
                <Form>
                  <Field
                    as={TextField}
                    label="Username"
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    type="text"
                    name="userName"
                    placeholder="Enter username"
                    id="outlined-basic"
                    helperText={<ErrorMessage name="email" />}
                    variant="outlined"
                    value={values.userName}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    margin="normal"
                    className={
                      errors.userName && touched.userName
                        ? "text-input error"
                        : "text-input"
                    }
                    fullWidth
                  />

                  <Field
                    as={TextField}
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    label="Password"
                    placeholder="Password"
                    name="password"
                    helperText={<ErrorMessage name="password" />}
                    type="password"
                    id="outlined-basic"
                    variant="outlined"
                    value={values.password}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={
                      errors.password && touched.password
                        ? "text-input error"
                        : "text-input"
                    }
                    fullWidth
                  />

                  <img
                    height="10%"
                    width="20%"
                    src={
                      "https://www.pandasecurity.com/en/mediacenter/src/uploads/2014/09/avoid-captcha.jpg"
                    }
                    alt="Captcha"
                  ></img>
                  <Field
                    as={TextField}
                    sx={{
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    label="Captcha"
                    placeholder="Captcha"
                    name="captcha"
                    helperText={<ErrorMessage name="captcha" />}
                    type="captcha"
                    id="outlined-basic"
                    variant="outlined"
                    value={values.captcha}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    fullWidth
                  />

                  <Button
                    type="submit"
                    color="primary"
                    variant="contained"
                    // fullWidth
                    required
                    disabled={isSubmitting}
                  >
                    Login
                  </Button>
                </Form>
              );
            }}
          </Formik>
          <br></br>
        </Box>
      </div>
      <Footer />
    </>
  );
};
export default Login;
