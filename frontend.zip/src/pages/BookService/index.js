import React, { useState ,useEffect} from "react";
import { MenuItem, Select, TextField, Button, Box } from "@mui/material";

import { BookService, getSlots } from "../../API/hotelBook";

import { Formik, Form } from "formik";

import "./signup.css";
import Header from "../../components/header";
import Footer from "../../components/footer";
const Signup = () => {
  let currentDate = new Date().toISOString().slice(0, 10) 
  const [date, setDate] = useState('');

  const [slotsOptions, setSlotOptions] = useState([]);

  const handlegetSlots = async (e, appNo, vehno, appType, loc) => {
    setDate(e.target.value);
    let payload = {

      applicationNumber: appNo,
      appointmentDate: date || e.target.value,
      vehicleNumber: vehno,
      appointmentType:appType,
      location:loc

    };
    if (appNo && vehno && e.target.value) {
      let res_slots = await getSlots(payload);
      console.log(res_slots);
      if(res_slots.message =='Slots Not Available'){
        alert('Slots not available for the selected date');
      } else {
      setSlotOptions(res_slots);
      }
    }
  };

  const handleCance =()=>{
    // 
  }
  useEffect(() => {
 
  }, []);


  return (
    <>
      <Header />
      <div className="mainDivSignup">
        <Box
          display="flex"
          flexDirection={"column"}
          maxWidth={400}
          alignItems="center"
          justifyContent={"center"}
          margin="auto"
          marginTop={5}
          padding={2}
          marginBottom={10}
          backgroundColor="white"
        >
          <Formik
            initialValues={{
              applicationNumber: "",
              city: "",
              service: "",
              vehicleNumber: "",
              date: date,
              appointmentType:"",
              location:""
            }}
            onSubmit={async (values) => {
              BookService(values, date);
            }}
            validateOnChange={false}
            validateOnBlur={false}
          >
            {(props) => {
              props.submitCount > 0 && (props.validateOnChange = true);
              const {
                values,

                isSubmitting,
                handleChange,
              } = props;
              return (
                <Form>
                <p>Select Location</p>
               
                <Select
                value={values.location}
                onChange={handleChange}
                name="location"
                label="location"
                size="small"
                fullWidth
              >
                  <MenuItem value="NewYork">New York</MenuItem>;
                  <MenuItem value="Dallas">Dallas</MenuItem>;
                  <MenuItem value="Kansas">Kansas</MenuItem>;
                  <MenuItem value="Chicago">Chicago</MenuItem>;
              
              </Select>
              <br></br>
             

              <p>Select Appointment Type</p>
               
              <Select
              value={values.appointmentType}
              onChange={handleChange}
              name="appointmentType"
              label="appointmentType"
              size="small"
              fullWidth
            >
                <MenuItem value="LLR">LLR</MenuItem>;
                <MenuItem value="VehicleRegistration">Vehicle Registration</MenuItem>;
            
            </Select>
            <br></br>
            <br></br>

                  <TextField
                    id="applicationNumber"
                    label="Application Number"
                    size="small"
                    fullWidth
                    type="text"
                    value={values.applicationNumber}
                    onChange={handleChange}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                  <TextField
                    fullWidth
                    size="small"
                    id="vehicleNumber"
                    label="Vehicle Number"
                    type="text"
                    style={{ marginTop: "5%" }}
                    value={values.vehicleNumber}
                    onChange={handleChange}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                  <TextField
                    fullWidth
                    id="date"
                    label="Select Date"
                    type="date"
                    size="small"
                    style={{ marginTop: "5%" }}
                    value={values.date || date}

                    onChange={(e) => {
                      handlegetSlots(
                        e,
                        values.applicationNumber,
                        values.vehicleNumber,
                        values.appointmentType,
                        values.location
                      );
                      handleChange();
                    }}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                  <p>Availabel Slots</p>
                  <Select
                    value={values.service}
                    onChange={handleChange}
                    name="service"
                    label="service"
                    size="small"
                    fullWidth
                  >
                    {slotsOptions.map((item) => {
                      return <MenuItem value={item}>{item}</MenuItem>;
                    })}
                  </Select>

                  <br></br>

                  <br></br>

                  <Button
                    type="submit"
                    sx={{
                      // width: { sm: 200, md: 300 },
                      "& .MuiInputBase-root": {
                        height: 40,
                      },
                    }}
                    color="primary"
                    variant="contained"
                    size="small"
                    fullWidth
                    required
                    disabled={isSubmitting}
                  >
                    Book Service
                  </Button>
                
                </Form>
              );
            }}
          </Formik>
          <br></br>
        </Box>
      </div>
      <Footer />
    </>
  );
};
export default Signup;
