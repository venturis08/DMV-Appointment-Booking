import { Grid, Typography } from "@mui/material";
const Footer = () => {
  return (
    <div style={{ width: "100%", height: "20%", background: "#4b95d1" }}>
      <Grid container>
        <Grid
          style={{ textAlign: "center", marginBottom: "3%", marginTop: "2%" }}
          item
          xs={12}
        >
          <Typography variant="h6">
            Powered By National Informatic Center
          </Typography>
        </Grid>
      </Grid>
    </div>
  );
};
export default Footer;
