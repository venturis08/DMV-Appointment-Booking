import logo from "../Images/logo.png";
import { Grid } from "@mui/material";
const Header = () => {
  const flag = localStorage.getItem("id") ? true : false;

  return (
    <div style={{ width: "100%", background: "#4b95d1" }}>
      <Grid container>
        <Grid ml={4} xs={6} container>
          <Grid item xs={2}>
            <img height="80px" src={logo} alt="logo" />
          </Grid>
          <Grid item xs={10}>
            <h2>Department of vehicles and licenses</h2>
          </Grid>
        </Grid>

        <Grid item xs={4} style={{ paddingRight: "2%" }}>
          <Grid container>
            <Grid item xs={4}>
              {flag && (
                <p
                  style={{ color: "white", textAlign: "right" }}
                  onClick={() => {
                    window.location.href = "/bookings";
                  }}
                >
                  My Appointments
                </p>
              )}
            </Grid>
            <Grid item xs={6}>
              {flag && (
                <p
                  style={{ color: "white", textAlign: "right" }}
                  onClick={() => {
                    window.location.href = "/bookservice";
                  }}
                >
                  Book Appointment
                </p>
              )}
            </Grid>
            {flag && (
              <Grid item xs={2}>
                <p
                  style={{ color: "white", textAlign: "right" }}
                  onClick={() => {
                    localStorage.clear();
                    window.location.href = "/login";
                  }}
                >
                  Logout
                </p>
              </Grid>
            )}
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};
export default Header;
